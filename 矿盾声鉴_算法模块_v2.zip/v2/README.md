# 矿盾声鉴 · 信号分解与识别算法模块 v2

## 目录结构

```
config.m                 所有可调参数（只改这里）
setup_paths.m            添加路径
run_selftest.m           自检（约 1 分钟，修改代码后先跑）
run_vmd_opt.m            模块一：优化 VMD 参数并分解信号（替代 main.m / main1.m）
run_vmd_compare.m        模块一：TTAO / GLO / 随机搜索 对比实验（替代 comparison.m）
run_step1_samples.m      模块二：原始数据 -> 滑窗样本（替代 data_summary.m）
run_step2_tfr.m          模块三：样本 -> 同步提取变换时频图（替代 Step1.m、Step2_JPG_Resize.m）
run_step3_cnn_lssvm.m    模块四：CNN 特征 + BKA 优化 LSSVM（替代 CNN_BKA_LSSVM.m）
src/                     自研函数
third_party/             第三方算法（见 THIRD_PARTY.md）
tools/                   验证用的辅助脚本（不属于软件本体）
data/                    数据
results/                 运行结果（按时间戳生成子目录）
```

## 环境

- MATLAB R2019b 及以上。模块一至三不需要任何工具箱（也能在 GNU Octave 10 中运行）。
- 模块四需要 **Deep Learning Toolbox**（R2021a 及以上，需支持 `OutputNetwork` 参数）；t-SNE 图需要 Statistics Toolbox，没有时会自动跳过。

## 使用

```matlab
run_selftest          % 1. 自检
run_vmd_opt           % 2. VMD 参数寻优与分解
run_vmd_compare       % 3. 优化器对比（20 次 × 3 种算法，约 10 分钟）
run_step1_samples     % 4. 需要先把 data.mat 放到 data/ 目录
run_step2_tfr
run_step3_cnn_lssvm
```

接入矿区音频：把 `cfg.vmd.signal_file` 改成 `.wav` 路径（采样率会自动读取）；分类数据按照 `run_step1_samples.m` 末尾的示例逐类读取。

## 结果解读要点

- `run_vmd_compare` 会给出每种算法的最优、均值、标准差、命中网格最优的比例，以及秩和检验 p 值。答辩时请使用均值±标准差，不要只报单次结果。
- `run_step3_cnn_lssvm` 报告的是 `n_repeats` 次独立实验在测试集上的均值±标准差。测试集不参与任何调参。
