function img = tfr_to_rgb(M, img_size, cmap)
%TFR_TO_RGB  时频矩阵 -> 归一化 RGB 图像（直接生成，不再截图保存 JPG）
%   原流程用 figure + saveas 保存 JPG 再读回缩放，速度慢且有压缩损失；
%   这里直接计算幅值、对数压缩、双线性缩放并映射颜色。
if nargin < 3 || isempty(cmap), cmap = jet(256); end
A = abs(M);
A = log1p(A / (max(A(:)) + eps) * 100) / log1p(100);  % 对数压缩到 [0,1]
A = resize_bilinear(A, img_size);
A = min(max(A, 0), 1);
idx = 1 + round(A * (size(cmap, 1) - 1));
img = reshape(cmap(idx, :), [img_size 3]);
end
